#!/bin/bash


sudo echo "The app started $date"